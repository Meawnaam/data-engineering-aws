import requests
import json
import os
import time
import shutil
import csv # สำหรับจัดการไฟล์ CSV
from datetime import datetime # สำหรับบันทึกเวลาปัจจุบัน

API_URL = "https://s7uw5e1k1e.execute-api.us-east-1.amazonaws.com/default/CreditDataIngester"
SUCCESS_DIR = "sent_success" # โฟลเดอร์สำหรับเก็บไฟล์ที่ส่งแล้ว
HISTORY_CSV = "transfer_history.csv" # ไฟล์เก็บประวัติ

def record_history(file_name, status, record_count):
    """ฟังก์ชันสำหรับบันทึกประวัติลง CSV"""
    file_exists = os.path.isfile(HISTORY_CSV)
    
    with open(HISTORY_CSV, mode='a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        # ถ้าเพิ่งสร้างไฟล์ครั้งแรก ให้ใส่ Header ก่อน
        if not file_exists:
            writer.writerow(['timestamp', 'file_name', 'status', 'record_count'])
        
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        writer.writerow([timestamp, file_name, status, record_count])

def send_data_to_pipeline():
    # 1. สร้างโฟลเดอร์เก็บไฟล์ที่ส่งสำเร็จถ้ายังไม่มี
    if not os.path.exists(SUCCESS_DIR):
        os.makedirs(SUCCESS_DIR)

    files_to_send = [f for f in os.listdir('.') if f.startswith('data_batch_') and f.endswith('.json')]
    
    if not files_to_send:
        print("✅ ไม่พบไฟล์ใหม่ที่ต้องส่ง (ทุกไฟล์อาจถูกย้ายไปที่ sent_success แล้ว)")
        return

    print(f"📡 พบไฟล์ใหม่ {len(files_to_send)} ชุด กำลังเตรียมยิงข้อมูล...")
    print("-" * 60)

    for file_name in sorted(files_to_send):
        print(f"🚀 กำลังส่งไฟล์: {file_name} ...", end=" ", flush=True)
        
        try:
            with open(file_name, 'r', encoding='utf-8') as f:
                payload = json.load(f)
                # นับจำนวน record ในไฟล์ (สมมติ payload เป็น list)
                count = len(payload) if isinstance(payload, list) else 1
            
            response = requests.post(API_URL, json=payload)
            
            if response.status_code == 200:
                print(f"✅ สำเร็จ! ({count} records)")
                
                # 2. บันทึกประวัติลง CSV
                record_history(file_name, "SUCCESS", count)
                
                # 3. ย้ายไฟล์ที่ส่งสำเร็จแล้วไปไว้ที่ SUCCESS_DIR
                shutil.move(file_name, os.path.join(SUCCESS_DIR, file_name))
            else:
                print(f"❌ ล้มเหลว! (Status: {response.status_code})")
                record_history(file_name, f"FAILED_{response.status_code}", count)
                
        except Exception as e:
            print(f"❌ เกิดข้อผิดพลาด: {str(e)}")
            record_history(file_name, "ERROR", 0)
        
        time.sleep(1)

    print("-" * 60)
    print(f"🎯 ภารกิจเสร็จสิ้น! คุณสามารถตรวจสอบประวัติได้ที่ไฟล์: {HISTORY_CSV}")

if __name__ == "__main__":
    send_data_to_pipeline()